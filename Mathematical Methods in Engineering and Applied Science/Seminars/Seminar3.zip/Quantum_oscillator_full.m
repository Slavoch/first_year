%% Eigenvalues of the Shroedinger equation for the harmonic oscillator
% Find eigenvalues of -u'' + x^2*u =lam*u subject to u(-inf)=u(inf)=0 
clear all; clc; 

% Discretization
% Define computational domain L and grid x_0, ..., x_n with the step h

L = 10;        %the x-domain is [-L, L] with large enough L to represent infinity 
n = 200;       %the number of grid points on the domain
h = 2*L/n;     %step size in x to approximate derivatives: 
               % u'' = (u(i+1)-2*u(i)+u(i-1))/h^2 
x = -L + h*(1:n)';

% Approximation
% Write the system for eigenvalue problem

Kn = 1/h^2*toeplitz([2 -1 zeros(1,n-2)]);    %the 2nd derivative matrix
A = Kn + diag(x.^2);                        %the full matrix to represent [-()''+x^2] 

% Linear algebra
% Solve the eigenvalue problem

[V D] = eig(A);                             %e-values/vectors of A

% Plots
% Choose which eigenvectors to plot
nn = [1 2 3 4 5];                          
subplot(311), plot(x,V(:,nn),'.-','MarkerSize',15), grid on
legend(int2str(nn')); 
title(['Wavefunctions of quantum harmonic oscillator at L=',int2str(L),', n=',int2str(n)]);

% Comparison with the theory
% Write the exact eigenvalues and extract the calculated ones
eig_exact = 2*(0:size(D,1))' + 1;           %exact e-values from QM books
eig_numer = diag(D);                        %numerically found values
eig_end = min(20,n);                        %how many e-values to show
subplot(312), plot(eig_exact(1:eig_end),'gx-','MarkerSize',10), grid on, hold on
subplot(312), plot(eig_numer(1:eig_end),'r.','MarkerSize',25), hold off
legend('exact','numerical','Location','NW'); title('Eigenvalues of quantum harmonic oscillator');

% Write the relative error. USE SEMILOG AXES
err = (eig_exact(1:eig_end) - eig_numer(1:eig_end))./eig_exact(1:eig_end);
subplot(313), semilogy(abs(err),'b.-','MarkerSize',10), grid on
title('Relative error in eigenvalues, |\lambda_{exact}-\lambda_{numerical}|/\lambda_{exact} ');
